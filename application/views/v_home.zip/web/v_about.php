<!-- Main Content -->
<div class="main-content pt-5 mt-5">
	<section class="section">
		<div class="section-body">
			<div class="card">
				<div class="card-header justify-content-center pt-4">
					<h3 class="text-primary mt-4">Tentang Kami</h3>
				</div>
				<!-- /.card-header -->
				<div class="card-body">
					<div class="row justify-content-center align-items-center">
						<div class="col-md-4">
							<img src="<?php echo base_url() ?>assets/about.png" class="img-fluid" style="max-height: 500px">
						</div>
						<div class="col-md-6 text-center">
							<h5 class="font-weight-normal">
								<b class="text-primary">MY BRAND</b> adalah sebuah perusahaan jasa lelang swasta penjualan barang bergerak melalui lelang yang terbuka untuk umum dengan penawaran harga secara online yang semkain mencapai harga tertinggi.
							</h5>
						</div>
					</div>
				</div>
				<!-- /.card-body -->

			</div>
		</div>
	</section>
</div>