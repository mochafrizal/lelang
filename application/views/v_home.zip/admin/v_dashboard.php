<div class="main-content">
	<section class="section">
		<div class="section-header">
			<h1>Dashboard</h1>
		</div>
		<div class="row">
			<div class="col-md-12">
				<?php echo $this->session->flashdata('pesan') ?>
			</div>
		</div>
	</section>
</div>